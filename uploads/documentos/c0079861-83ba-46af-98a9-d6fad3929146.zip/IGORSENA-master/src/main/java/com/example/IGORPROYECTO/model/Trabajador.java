package com.example.IGORPROYECTO.model;

public class Trabajador {
    
}
