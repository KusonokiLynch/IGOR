package com.example.IGORPROYECTO.service;

public class ClienteService {
    
}
