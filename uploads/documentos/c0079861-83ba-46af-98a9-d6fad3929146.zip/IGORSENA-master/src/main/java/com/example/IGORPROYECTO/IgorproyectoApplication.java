package com.example.IGORPROYECTO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IgorproyectoApplication {

	public static void main(String[] args) {
		SpringApplication.run(IgorproyectoApplication.class, args);
	}

}
