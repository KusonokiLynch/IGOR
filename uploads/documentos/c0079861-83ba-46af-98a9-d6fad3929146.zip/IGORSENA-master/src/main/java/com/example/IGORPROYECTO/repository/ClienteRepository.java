package com.example.IGORPROYECTO.repository;

public class ClienteRepository {
    
}
