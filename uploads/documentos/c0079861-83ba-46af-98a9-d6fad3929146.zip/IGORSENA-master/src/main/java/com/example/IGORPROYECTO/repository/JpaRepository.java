package com.example.IGORPROYECTO.repository;

public interface JpaRepository<T1, T2> {

}
