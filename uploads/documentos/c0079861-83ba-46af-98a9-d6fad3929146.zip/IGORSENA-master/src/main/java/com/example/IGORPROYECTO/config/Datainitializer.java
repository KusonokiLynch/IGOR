package com.example.IGORPROYECTO.config;

public class Datainitializer {
    
}
